package aulasjava;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class TelaListaCompras extends JFrame {
    private ArrayList<String> compras = new ArrayList<>();
    private DefaultListModel<String> modelo = new DefaultListModel<>();
    private JList<String> lista;

    public TelaListaCompras() {
        setTitle("Lista de Compras");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        lista = new JList<>(modelo);

        JTextField campoItem = new JTextField();
        JButton btnAdicionar = new JButton("Adicionar");

        btnAdicionar.addActionListener(e -> {
            String item = campoItem.getText();
            if (!item.isEmpty()) {
                compras.add(item);
                modelo.addElement(item);
                campoItem.setText("");
            }
        });

        JPanel painelTopo = new JPanel(new BorderLayout());
        painelTopo.add(campoItem, BorderLayout.CENTER);
        painelTopo.add(btnAdicionar, BorderLayout.EAST);

        add(painelTopo, BorderLayout.NORTH);
        add(new JScrollPane(lista), BorderLayout.CENTER);
    }
}
