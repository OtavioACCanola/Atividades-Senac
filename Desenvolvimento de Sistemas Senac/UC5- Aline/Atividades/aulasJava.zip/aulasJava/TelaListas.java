package aulasjava;

import javax.swing.*;
import java.awt.*;

public class TelaListas extends JFrame {

    public TelaListas() {
        setTitle("Atividades com Listas");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1, 10, 10));

        // Botões
        JButton btnListaCompras = new JButton("Lista de Compras");
        JButton btnListaTarefas = new JButton("Lista de Tarefas");
        JButton btnAgendaContatos = new JButton("Agenda de Contatos");

        // Ações
        btnListaCompras.addActionListener(e -> {
            new TelaListaCompras().setVisible(true);
        });

        btnListaTarefas.addActionListener(e -> {
            new TelaListaTarefas().setVisible(true);
        });

        btnAgendaContatos.addActionListener(e -> {
            new TelaAgendaContatos().setVisible(true);
        });

        // Adiciona ao painel
        panel.add(btnListaCompras);
        panel.add(btnListaTarefas);
        panel.add(btnAgendaContatos);

        add(panel);
    }
}
